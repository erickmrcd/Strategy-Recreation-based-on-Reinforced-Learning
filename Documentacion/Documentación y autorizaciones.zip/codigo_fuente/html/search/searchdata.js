var indexSectionsWithContent =
{
  0: "abcdefghilmnoprstuvwxyz",
  1: "abcefghilmopstuv",
  2: "abcefghilmpstuv",
  3: "abcdefghinoprstu",
  4: "agimostuxz",
  5: "r",
  6: "cg",
  7: "bcdfgmprswy",
  8: "acdhiu",
  9: "o"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "properties",
  9: "events"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Clases",
  2: "Archivos",
  3: "Funciones",
  4: "Variables",
  5: "typedefs",
  6: "Enumeraciones",
  7: "Valores de enumeraciones",
  8: "Propiedades",
  9: "Eventos"
};

