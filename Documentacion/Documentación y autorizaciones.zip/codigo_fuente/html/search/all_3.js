var searchData=
[
  ['damage_0',['Damage',['../class_health_system.html#a58f31a6d40eb91eacd5fdd00bb028aea',1,'HealthSystem.Damage()'],['../class_unit.html#abf43d9f4c8ccd6f284a1e8982a226d5d',1,'Unit.Damage()'],['../class_unit.html#a5f17bddebde4cc08f671b2eda8040755',1,'Unit.Damage(int damageAmount)']]],
  ['damagemodifier_1',['DamageModifier',['../class_unit_stats.html#aaf3c5388c24eb7a824f75d46b7bbe145',1,'UnitStats']]],
  ['damageradius_2',['DamageRadius',['../class_fire_ball.html#a46a84bbb2cef78c8a5d9a924f489f617',1,'FireBall']]],
  ['distance_3',['Distance',['../struct_grid_position.html#a664f34796a21307aea1ef0e6cfeed39c',1,'GridPosition']]],
  ['druid_4',['Druid',['../class_unit.html#af933a3e70e658d50e9749d328b5365ccae7b1c3af3203c42e8a5450beb229c09e',1,'Unit']]]
];
