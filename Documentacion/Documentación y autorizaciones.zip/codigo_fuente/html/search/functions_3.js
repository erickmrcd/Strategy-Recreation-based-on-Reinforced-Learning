var searchData=
[
  ['damage_0',['Damage',['../class_health_system.html#a58f31a6d40eb91eacd5fdd00bb028aea',1,'HealthSystem.Damage()'],['../class_unit.html#abf43d9f4c8ccd6f284a1e8982a226d5d',1,'Unit.Damage()'],['../class_unit.html#a5f17bddebde4cc08f671b2eda8040755',1,'Unit.Damage(int damageAmount)']]],
  ['distance_1',['Distance',['../struct_grid_position.html#a664f34796a21307aea1ef0e6cfeed39c',1,'GridPosition']]]
];
