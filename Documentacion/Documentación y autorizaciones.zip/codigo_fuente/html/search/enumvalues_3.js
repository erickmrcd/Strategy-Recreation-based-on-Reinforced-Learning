var searchData=
[
  ['fighter_0',['Fighter',['../class_unit.html#af933a3e70e658d50e9749d328b5365cca5db14795d4c6928f94927d0c0a060bee',1,'Unit']]]
];
