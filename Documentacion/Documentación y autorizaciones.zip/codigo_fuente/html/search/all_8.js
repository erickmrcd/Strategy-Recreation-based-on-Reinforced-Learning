var searchData=
[
  ['inputmanager_0',['InputManager',['../class_input_manager.html',1,'']]],
  ['inputmanager_2ecs_1',['InputManager.cs',['../_input_manager_8cs.html',1,'']]],
  ['instance_2',['Instance',['../class_game_manager.html#ad3e717f4fb0f378b969f4457de81f23e',1,'GameManager.Instance'],['../class_grid_system_visual.html#a443690ce7764c5fb451969e1d980c750',1,'GridSystemVisual.Instance'],['../class_input_manager.html#afb55d4ebb7290ab0950c3fd7d3825729',1,'InputManager.Instance'],['../class_level_grid.html#a2289e5f589c75631e3a0348a0992b7d5',1,'LevelGrid.Instance'],['../class_pathfinding.html#af1d933f3be17fbf40b51c744a6a5817b',1,'Pathfinding.Instance'],['../class_screen_shake.html#ac081015dc732aeffd6a03642576767c6',1,'ScreenShake.Instance'],['../class_turn_system.html#afb88390bd634f5f5d61677c68819ef3b',1,'TurnSystem.Instance'],['../class_unit_action_system.html#aade075caf30c86ba81a057352a0f0a55',1,'UnitActionSystem.Instance'],['../class_unit_manager.html#a4f9d9d8f439ebd7e4259c9924c8291a4',1,'UnitManager.Instance']]],
  ['interactaction_3',['InteractAction',['../class_interact_action.html',1,'']]],
  ['interactaction_2ecs_4',['InteractAction.cs',['../_interact_action_8cs.html',1,'']]],
  ['isactive_5',['isActive',['../class_base_action.html#a6e99c6e9b79dd10395d595916cc0bd72',1,'BaseAction']]],
  ['isenemy_6',['IsEnemy',['../class_unit.html#a8b4a979fcc5105ba9fec1629284a6653',1,'Unit']]],
  ['isplayerturn_7',['IsPlayerTurn',['../class_turn_system.html#a0cd72934034eb02591fb17a108db3e94',1,'TurnSystem']]],
  ['israngedunit_8',['IsRangedUnit',['../class_unit.html#a16377ee1d03c00cee4a0ce64b8cf7b4b',1,'Unit']]],
  ['isvalidactiongridposition_9',['IsValidActionGridPosition',['../class_base_action.html#a7cfb19a8aedc954d6f2ed6e7f733f49b',1,'BaseAction']]],
  ['isvalidgridposition_10',['IsValidGridPosition',['../class_grid_system.html#a1d0a9d8231ae895573fcb35a372f6e6c',1,'GridSystem.IsValidGridPosition()'],['../class_level_grid.html#a44154127c6c78b958c7e84a3d8427192',1,'LevelGrid.IsValidGridPosition()']]],
  ['iswalkable_11',['IsWalkable',['../class_path_node.html#ae69543eb419d4257e4278f709b56f193',1,'PathNode']]],
  ['iswalkablegridposition_12',['IsWalkableGridPosition',['../class_pathfinding.html#aefe3051f1be823dc6a77c3fa86008576',1,'Pathfinding']]]
];
