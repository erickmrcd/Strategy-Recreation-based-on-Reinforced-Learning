var searchData=
[
  ['warlock_0',['Warlock',['../class_unit.html#af933a3e70e658d50e9749d328b5365cca21305b754e03843876abc27387a0e57e',1,'Unit']]],
  ['wizard_1',['Wizard',['../class_unit.html#af933a3e70e658d50e9749d328b5365cca5af874093e5efcbaeb4377b84c5f2ec5',1,'Unit']]]
];
