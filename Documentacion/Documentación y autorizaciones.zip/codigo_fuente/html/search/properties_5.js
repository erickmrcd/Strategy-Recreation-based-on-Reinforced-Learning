var searchData=
[
  ['unitstats_0',['UnitStats',['../class_unit.html#a7906bb3b2a3069214c1817f1451161fa',1,'Unit']]]
];
