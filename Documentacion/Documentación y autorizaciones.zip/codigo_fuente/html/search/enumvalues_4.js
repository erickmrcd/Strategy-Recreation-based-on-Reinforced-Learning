var searchData=
[
  ['gameover_0',['GameOver',['../_game_manager_8cs.html#a7899b65f1ea0f655e4bbf8d2a5714285a8f347bc7cebca9fa6d97e70c6bc29eb3',1,'GameManager.cs']]],
  ['green_1',['Green',['../class_grid_system_visual.html#a194af742b6d7341712d22fb79b0a724ead382816a3cbeed082c9e216e7392eed1',1,'GridSystemVisual']]]
];
