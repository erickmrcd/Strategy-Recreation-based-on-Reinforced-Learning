var searchData=
[
  ['instance_0',['Instance',['../class_game_manager.html#ad3e717f4fb0f378b969f4457de81f23e',1,'GameManager.Instance'],['../class_grid_system_visual.html#a443690ce7764c5fb451969e1d980c750',1,'GridSystemVisual.Instance'],['../class_input_manager.html#afb55d4ebb7290ab0950c3fd7d3825729',1,'InputManager.Instance'],['../class_level_grid.html#a2289e5f589c75631e3a0348a0992b7d5',1,'LevelGrid.Instance'],['../class_pathfinding.html#af1d933f3be17fbf40b51c744a6a5817b',1,'Pathfinding.Instance'],['../class_screen_shake.html#ac081015dc732aeffd6a03642576767c6',1,'ScreenShake.Instance'],['../class_turn_system.html#afb88390bd634f5f5d61677c68819ef3b',1,'TurnSystem.Instance'],['../class_unit_action_system.html#aade075caf30c86ba81a057352a0f0a55',1,'UnitActionSystem.Instance'],['../class_unit_manager.html#a4f9d9d8f439ebd7e4259c9924c8291a4',1,'UnitManager.Instance']]],
  ['israngedunit_1',['IsRangedUnit',['../class_unit.html#a16377ee1d03c00cee4a0ce64b8cf7b4b',1,'Unit']]]
];
