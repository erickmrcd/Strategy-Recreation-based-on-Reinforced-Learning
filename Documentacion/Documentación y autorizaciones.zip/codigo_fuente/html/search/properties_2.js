var searchData=
[
  ['damagemodifier_0',['DamageModifier',['../class_unit_stats.html#aaf3c5388c24eb7a824f75d46b7bbe145',1,'UnitStats']]],
  ['damageradius_1',['DamageRadius',['../class_fire_ball.html#a46a84bbb2cef78c8a5d9a924f489f617',1,'FireBall']]]
];
