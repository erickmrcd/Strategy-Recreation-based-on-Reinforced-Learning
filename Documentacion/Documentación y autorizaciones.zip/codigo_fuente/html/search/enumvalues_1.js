var searchData=
[
  ['cleric_0',['Cleric',['../class_unit.html#af933a3e70e658d50e9749d328b5365cca88f6c01a3b5711ec2a896c9f5462497c',1,'Unit']]]
];
