var searchData=
[
  ['armormodifier_0',['ArmorModifier',['../class_unit_stats.html#a6e417a5af54224255ff866b78613fcb2',1,'UnitStats']]]
];
