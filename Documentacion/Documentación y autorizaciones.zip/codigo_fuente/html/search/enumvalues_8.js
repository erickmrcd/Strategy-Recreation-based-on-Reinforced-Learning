var searchData=
[
  ['sorcerer_0',['Sorcerer',['../class_unit.html#af933a3e70e658d50e9749d328b5365cca39babca9e3d0ceda5051773a25fe2a4f',1,'Unit']]]
];
