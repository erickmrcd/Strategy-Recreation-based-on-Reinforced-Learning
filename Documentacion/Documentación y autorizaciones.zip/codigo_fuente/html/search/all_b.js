var searchData=
[
  ['nextturn_0',['nextTurn',['../class_turn_system.html#a4c1ddd3afc8aa95d3ae11db137df4011',1,'TurnSystem']]]
];
