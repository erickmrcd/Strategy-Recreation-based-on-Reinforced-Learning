var searchData=
[
  ['characterportrait_0',['CharacterPortrait',['../class_unit.html#ae57c9bc185dc531036101b231af67114',1,'Unit']]]
];
