var searchData=
[
  ['gamestate_0',['GameState',['../_game_manager_8cs.html#a7899b65f1ea0f655e4bbf8d2a5714285',1,'GameManager.cs']]],
  ['gridvisualtype_1',['GridVisualType',['../class_grid_system_visual.html#a194af742b6d7341712d22fb79b0a724e',1,'GridSystemVisual']]]
];
