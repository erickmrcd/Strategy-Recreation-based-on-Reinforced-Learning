var searchData=
[
  ['paladin_0',['Paladin',['../class_unit.html#af933a3e70e658d50e9749d328b5365ccaf4c17b587a99337e4f5a8e37cdb2a858',1,'Unit']]],
  ['play_1',['Play',['../_game_manager_8cs.html#a7899b65f1ea0f655e4bbf8d2a5714285ade3c731be5633838089a07179d301d7b',1,'GameManager.cs']]]
];
