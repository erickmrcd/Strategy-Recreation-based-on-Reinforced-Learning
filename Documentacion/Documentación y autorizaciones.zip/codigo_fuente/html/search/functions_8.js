var searchData=
[
  ['isenemy_0',['IsEnemy',['../class_unit.html#a8b4a979fcc5105ba9fec1629284a6653',1,'Unit']]],
  ['isplayerturn_1',['IsPlayerTurn',['../class_turn_system.html#a0cd72934034eb02591fb17a108db3e94',1,'TurnSystem']]],
  ['isvalidactiongridposition_2',['IsValidActionGridPosition',['../class_base_action.html#a7cfb19a8aedc954d6f2ed6e7f733f49b',1,'BaseAction']]],
  ['isvalidgridposition_3',['IsValidGridPosition',['../class_grid_system.html#a1d0a9d8231ae895573fcb35a372f6e6c',1,'GridSystem.IsValidGridPosition()'],['../class_level_grid.html#a44154127c6c78b958c7e84a3d8427192',1,'LevelGrid.IsValidGridPosition()']]],
  ['iswalkable_4',['IsWalkable',['../class_path_node.html#ae69543eb419d4257e4278f709b56f193',1,'PathNode']]],
  ['iswalkablegridposition_5',['IsWalkableGridPosition',['../class_pathfinding.html#aefe3051f1be823dc6a77c3fa86008576',1,'Pathfinding']]]
];
