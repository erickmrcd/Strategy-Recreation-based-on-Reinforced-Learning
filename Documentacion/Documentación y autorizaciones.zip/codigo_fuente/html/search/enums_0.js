var searchData=
[
  ['characterclass_0',['CharacterClass',['../class_unit.html#af933a3e70e658d50e9749d328b5365cc',1,'Unit']]]
];
